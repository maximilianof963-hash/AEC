ALTER TABLE `situaciones` RENAME COLUMN `registradoPorId` TO `creadoPorId`;--> statement-breakpoint
ALTER TABLE `seguimientos` MODIFY COLUMN `registradoPorId` int;--> statement-breakpoint
ALTER TABLE `situaciones` MODIFY COLUMN `cursoDivision` varchar(32) NOT NULL;--> statement-breakpoint
ALTER TABLE `situaciones` MODIFY COLUMN `adultoInformante` varchar(128) NOT NULL;--> statement-breakpoint
ALTER TABLE `situaciones` MODIFY COLUMN `creadoPorId` int;--> statement-breakpoint
ALTER TABLE `seguimientos` DROP COLUMN `fueEfectiva`;