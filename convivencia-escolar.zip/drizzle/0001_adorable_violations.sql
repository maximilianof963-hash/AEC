CREATE TABLE `seguimientos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`situacionId` int NOT NULL,
	`tipoAccion` enum('llamado_atencion','apercibimiento_oral','apercibimiento_escrito','amonestacion','accion_reparadora','acta_compromiso','derivacion_consejo','intervencion_familiar','separacion_temporaria','otro') NOT NULL,
	`descripcion` text NOT NULL,
	`fechaAccion` timestamp NOT NULL,
	`fueEfectiva` boolean,
	`observaciones` text,
	`registradoPorId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `seguimientos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `situaciones` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fechaHecho` timestamp NOT NULL,
	`cursoDivision` varchar(64) NOT NULL,
	`adultoInformante` varchar(256) NOT NULL,
	`rolInformante` enum('docente','preceptor','edayo','directivo') NOT NULL,
	`descripcion` text NOT NULL,
	`cantidadEstudiantes` int NOT NULL DEFAULT 1,
	`estudiantesDescripcion` text,
	`contexto` enum('aula','recreo','pasillo','acto_escolar','actividad_extracurricular','redes_sociales','otro') NOT NULL,
	`contextoDetalle` text,
	`hayReincidencia` boolean NOT NULL DEFAULT false,
	`reincidenciaDetalle` text,
	`hayMedidasPrevias` boolean NOT NULL DEFAULT false,
	`medidasPreviasDetalle` text,
	`estado` enum('pendiente_analisis','analizado','en_seguimiento','resuelto','derivado_consejo') NOT NULL DEFAULT 'pendiente_analisis',
	`clasificacionSugerida` enum('leve','grave','muy_grave'),
	`informeIA` json,
	`registradoPorId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `situaciones_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `institutionalRole` enum('docente','preceptor','edayo','directivo','admin') DEFAULT 'docente' NOT NULL;